import React from 'react';

export default function App() {
  return (
    <div className="p-4 text-center">
      <h1 className="text-4xl font-bold">Reto BachiMente</h1>
      <p className="mt-2 text-lg">¡Explora los reinos del conocimiento y gana XP!</p>
    </div>
  );
}
