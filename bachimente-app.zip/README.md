# Reto BachiMente

Una app educativa para estudiantes de tercero de bachillerato.

## Cómo ejecutar el proyecto

1. Instala Node.js y Vite
2. Ejecuta:

```bash
npm install
npm run dev
```

3. Abre tu navegador en http://localhost:5173
